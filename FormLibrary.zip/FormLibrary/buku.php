<?php require "koneksi.php" ?>
<?php
$query = "select * from buku";
$result = mysqli_query($db, $query);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Data Buku</title>
  </head>
  <body>
  	<div class="container">
  		<div class="row">
    		<div class="col-sm">
          
          <br />
          <h2>My Library</h2>
          <p>Huda Fat - 17.11.1613</p>
          <a href="add.php" class="btn btn-primary">Tambah Buku</a>
          <?php 
            $query = "SELECT B.judul, B.pengarang, B.th_terbit, K.nama_kategori 
            FROM buku B 
            JOIN kategori K
            ON B.id_kategori=K.id_kategori";
            $result = mysqli_query($db, $query);
            ?>
          <br /><br />

          <table class="table table-striped">
            <thead>
              <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Pengarang</th>
                <th>Tahun terbit</th>
                <th>Kategori</th>
                <th>Opsi</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; while($buku = mysqli_fetch_array($result)): ?>
              <tr>
                <td><?php echo $no++?></td>
                <td><?php echo $buku['judul']?></td>
                <td><?php echo $buku['pengarang']?></td>
                <td><?php echo $buku['th_terbit']?></td>
                <td><?php echo $buku['nama_kategori']?></td>
                <td>
                  <a href="edit.php?id=<?php echo $buku['id']?>"
                  class="btn btn-success btn-sm">edit</a>
                </td>
                <td>
                  <a href="delete.php?id=<?php echo $buku['id']?>" class="btn btn-danger btn-sm"
                  onclick="javascript: return confirm('Anda yakin hapus ?')">delete</a>
                </td>
                <td>
                </td>
              </tr>
              <?php endwhile;?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </body>
</html>